package com.example.course_dashboard_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
