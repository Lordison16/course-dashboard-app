import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Course Dashboard',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const OnboardingScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade700,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.school,
              size: 80,
              color: Colors.white,
            ),
            const SizedBox(height: 20),
            Text(
              'Course Dashboard',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 20),
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<Map<String, String>> onboardingData = [
    {
      'title': 'Welcome to Course Dashboard',
      'description': 'Access all your courses in one place and track your progress easily.',
      'image': '🎓',
    },
    {
      'title': 'Explore Various Courses',
      'description': 'Discover courses from different categories like Science, Arts, and Technology.',
      'image': '📚',
    },
    {
      'title': 'Enroll with Ease',
      'description': 'Quickly enroll in courses with our simple one-tap enrollment system.',
      'image': '🚀',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: onboardingData.length,
                onPageChanged: (int page) {
                  setState(() {
                    _currentPage = page;
                  });
                },
                itemBuilder: (context, index) {
                  return OnboardingPage(
                    title: onboardingData[index]['title']!,
                    description: onboardingData[index]['description']!,
                    image: onboardingData[index]['image']!,
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                onboardingData.length,
                (index) => buildDot(index: index),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(30.0),
              child: ElevatedButton(
                onPressed: () {
                  if (_currentPage == onboardingData.length - 1) {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (context) => const MainDashboard()),
                    );
                  } else {
                    _pageController.nextPage(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.ease,
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade700,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  _currentPage == onboardingData.length - 1 ? 'Get Started' : 'Next',
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  AnimatedContainer buildDot({required int index}) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: const EdgeInsets.only(right: 8),
      height: 8,
      width: _currentPage == index ? 24 : 8,
      decoration: BoxDecoration(
        color: _currentPage == index ? Colors.blue.shade700 : Colors.grey,
        borderRadius: BorderRadius.circular(4),
      ),
    );
  }
}

class OnboardingPage extends StatelessWidget {
  final String title;
  final String description;
  final String image;

  const OnboardingPage({
    super.key,
    required this.title,
    required this.description,
    required this.image,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(40.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            image,
            style: const TextStyle(fontSize: 80),
          ),
          const SizedBox(height: 40),
          Text(
            title,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.blue.shade700,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Text(
            description,
            style: const TextStyle(
              fontSize: 16,
              color: Colors.grey,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class MainDashboard extends StatefulWidget {
  const MainDashboard({super.key});

  @override
  State<MainDashboard> createState() => _MainDashboardState();
}

class _MainDashboardState extends State<MainDashboard> {
  int _selectedIndex = 0;
  String _selectedCategory = 'All';
  bool _isButtonExpanded = false;
  final List<Map<String, dynamic>> _enrolledCourses = [];

  final List<Map<String, dynamic>> courses = [
    {
      'name': 'Introduction to Flutter',
      'instructor': 'Dr. Sarah Johnson',
      'icon': Icons.developer_mode,
      'category': 'Technology',
    },
    {
      'name': 'Organic Chemistry',
      'instructor': 'Prof. Michael Chen',
      'icon': Icons.science,
      'category': 'Science',
    },
    {
      'name': 'Renaissance Art History',
      'instructor': 'Dr. Emily Williams',
      'icon': Icons.palette,
      'category': 'Arts',
    },
    {
      'name': 'Advanced Python Programming',
      'instructor': 'Prof. David Lee',
      'icon': Icons.code,
      'category': 'Technology',
    },
    {
      'name': 'Molecular Biology',
      'instructor': 'Dr. Jennifer Kim',
      'icon': Icons.biotech,
      'category': 'Science',
    },
    {
      'name': 'Modern Literature',
      'instructor': 'Prof. Robert Garcia',
      'icon': Icons.menu_book,
      'category': 'Arts',
    },
  ];

  final List<String> categories = ['All', 'Science', 'Arts', 'Technology'];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _showExitDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Exit Confirmation'),
          content: const Text('Are you sure you want to exit the app?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('No'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                // In a real app, you might want to use SystemNavigator.pop() to exit
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('App would exit now')),
                );
              },
              child: const Text('Yes'),
            ),
          ],
        );
      },
    );
  }

  void _enrollInCourse(Map<String, dynamic> course) {
    if (!_enrolledCourses.contains(course)) {
      setState(() {
        _enrolledCourses.add(course);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Enrolled in ${course['name']}')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Already enrolled in ${course['name']}')),
      );
    }
  }

  List<Widget> _getTabContent() {
    switch (_selectedIndex) {
      case 0:
        return [
          const Text(
            'My Courses',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          _enrolledCourses.isEmpty
              ? const Column(
                  children: [
                    Icon(Icons.school, size: 60, color: Colors.grey),
                    SizedBox(height: 16),
                    Text('No courses enrolled yet. Go to Courses tab to enroll!'),
                  ],
                )
              : Expanded(
                  child: ListView.builder(
                    itemCount: _enrolledCourses.length,
                    itemBuilder: (context, index) {
                      final course = _enrolledCourses[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 0),
                        child: ListTile(
                          leading: Icon(course['icon'], color: Colors.blue.shade700),
                          title: Text(
                            course['name'],
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text('Instructor: ${course['instructor']}'),
                          trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                        ),
                      );
                    },
                  ),
                ),
        ];
      case 1:
        final filteredCourses = _selectedCategory == 'All'
            ? courses
            : courses.where((course) => course['category'] == _selectedCategory).toList();

        return [
          const Text(
            'Available Courses',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          // Dropdown for course category
          DropdownButton<String>(
            value: _selectedCategory,
            items: categories.map((String category) {
              return DropdownMenuItem<String>(
                value: category,
                child: Text(category),
              );
            }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _selectedCategory = newValue!;
              });
            },
          ),
          const SizedBox(height: 10),
          Text('Selected Category: $_selectedCategory'),
          const SizedBox(height: 20),
          // Course list
          Expanded(
            child: ListView.builder(
              itemCount: filteredCourses.length,
              itemBuilder: (context, index) {
                final course = filteredCourses[index];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 0),
                  child: ListTile(
                    leading: Icon(course['icon'], color: Colors.blue.shade700),
                    title: Text(
                      course['name'],
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text('Instructor: ${course['instructor']}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.add_circle, color: Colors.green),
                      onPressed: () => _enrollInCourse(course),
                    ),
                  ),
                );
              },
            ),
          ),
        ];
      case 2:
        return [
          const Center(
            child: Text(
              'User Profile',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 20),
          const CircleAvatar(
            radius: 50,
            backgroundColor: Colors.blue,
            child: Icon(Icons.person, size: 50, color: Colors.white),
          ),
          const SizedBox(height: 20),
          const Text('John Doe', style: TextStyle(fontSize: 20)),
          const SizedBox(height: 10),
          const Text('Computer Science Student'),
          const SizedBox(height: 20),
          Text('Enrolled Courses: ${_enrolledCourses.length}'),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            onPressed: _showExitDialog,
            icon: const Icon(Icons.logout),
            label: const Text('Logout'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
          ),
        ];
      default:
        return [const Text('Invalid tab')];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Course Dashboard'),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _getTabContent(),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.school),
            label: 'Courses',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue.shade700,
        onTap: _onItemTapped,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _isButtonExpanded = !_isButtonExpanded;
          });
          
          // Show a dialog to add a new course
          if (_selectedIndex == 1) {
            showDialog(
              context: context,
              builder: (BuildContext context) {
                String newCourseName = '';
                String newInstructor = '';
                String newCategory = 'Technology';

                return AlertDialog(
                  title: const Text('Add New Course'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        decoration: const InputDecoration(labelText: 'Course Name'),
                        onChanged: (value) => newCourseName = value,
                      ),
                      TextField(
                        decoration: const InputDecoration(labelText: 'Instructor'),
                        onChanged: (value) => newInstructor = value,
                      ),
                      DropdownButtonFormField<String>(
                        value: newCategory,
                        items: categories.where((c) => c != 'All').map((String category) {
                          return DropdownMenuItem<String>(
                            value: category,
                            child: Text(category),
                          );
                        }).toList(),
                        onChanged: (String? value) {
                          if (value != null) newCategory = value;
                        },
                      ),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        if (newCourseName.isNotEmpty && newInstructor.isNotEmpty) {
                          setState(() {
                            courses.add({
                              'name': newCourseName,
                              'instructor': newInstructor,
                              'icon': Icons.menu_book,
                              'category': newCategory,
                            });
                          });
                          Navigator.of(context).pop();
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Added $newCourseName')),
                          );
                        }
                      },
                      child: const Text('Add'),
                    ),
                  ],
                );
              },
            );
          }
          
          // Reset the button size after a delay
          Future.delayed(const Duration(milliseconds: 500), () {
            setState(() {
              _isButtonExpanded = false;
            });
          });
        },
        child: AnimatedScale(
          scale: _isButtonExpanded ? 1.2 : 1.0,
          duration: const Duration(milliseconds: 300),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}